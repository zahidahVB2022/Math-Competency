class SchoolList{
    
    School List[] = new School[3]; // can access details of each school
    int i =0;
    
    void addSchool(School x){
        List[i] = x;
        i++;
    }
    
    public School getSchool(int choice){
    		
    		School s=null; // declare a school variable
    		s = this.List[choice-1];
    	    System.out.println(s.name);
    		return s;
    }
}