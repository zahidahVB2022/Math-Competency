/* 
1) get the score for a particular school in a particular year
2) list out the average score for each schools
3) list out the standard deviation for each schools sort the list
*/

import java.util.Scanner;
public class Main
{
	public static void main(String[] args) {
	    
	    Scanner input = new Scanner(System.in);
	    
	    // create school 
		School samura = new School();
		samura.name = "Sekolah Menengah Sains Muar";
		samura.setAddress("Jalan Tanjung Agas", "Tangkak", "84000", "Johor");
		samura.setPrincipal("Ahmad", "Zamri");
		
		School sksu = new School();
		sksu.name = "Sekolah Kebangsaan Saujana Utama";
		sksu.setAddress("Jalan Cemara", "Sungai Buloh", "47000", "Selangor");
		sksu.setPrincipal("Jailani", "Batil");
		
		// add school to the school list
		SchoolList list = new SchoolList();
		list.addSchool(samura);
		list.addSchool(sksu);
		
		for (int i=0; i < list.List.length; i++) {
		    if (list.List[i] != null) {
                System.out.println((i+1) + ": " + list.List[i].name); //access array of the object list
		    }
    	}
    		System.out.print("Choose school to add marks: ");
    		int choice = input.nextInt();
		    School s = list.getSchool(choice);
		    input.nextLine();
		    
		    
		// get score each student for particular school 
		for(int k=0; k < list.List.length; k++){
		    
    		//get score for each student in particular school
		    char response = ' ';
        	int i = 0;
        	while (response != 'Q' && i < s.student.length){    // max student 10
        	    System.out.println("Student " + (i+1));
        	    System.out.print("Name: ");
                String name = input.nextLine();
                System.out.print("ID: ");
                String ID = input.nextLine();
                System.out.print("Class Name: ");
                String className = input.nextLine();
                System.out.print("Score: ");
                int score = input.nextInt();
                
                Marks studentMarks = new Marks();
                studentMarks.addMark(i, name, ID, className, score);                
                s.student[i] = studentMarks; //student[0] = array of Marks
                i++;
                
                System.out.print("Enter Q to quit: ");
                response = input.next().charAt(0);
                input.nextLine();
        	}
		}
		
		// list out the average score for each schools
		// list out the standard deviation for each schools sort the list
		
		for(int m=0; m < list.List.length; m++){
		    School sname = list.List[m]; //list.List[0] = samura //list.List[1] = sksu
		    System.out.print("Average of " + list.List[m].name + " : " + sname.calcAverage(sname)); 
		    System.out.print("Standard Deviation of " + list.List[m].name + " : " + sname.calcStandDev(sname));
		}

	}
}
