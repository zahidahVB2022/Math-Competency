//name, address (splitted), principal's name (fname, lname)

class School{
    String name;
    String address,streetName,area,state,zipCode;
    String principal,fname,lname;
    
    Marks student[] = new Marks[10]; //can access details of each mark
    
    
    void setAddress(String streetName, String area, String state, String zipCode){
        address = streetName + ", " + area + ", " + zipCode + ", " + state;
    }
    
    void setPrincipal(String fname, String lname){
        principal = fname + " " + lname;
    }
    
    
    double calcAverage(School s){
        double total=0, average;
        for(int i=0; i < 10; i++){
            total += s.student[i].score;
        }
        average = total/10;
        return average;
    }
    
    double calcStandDev(School s){
        double sum = 0.0, standardDeviation = 0.0;

        for (int i=0; i < 10; i++) {
            sum += s.student[i].score;
        }

        double avg = sum/10;

        for (int i=0; i < 10; i++) {
            standardDeviation += Math.pow(s.student[i].score - avg, 2);
        }

        return Math.sqrt(standardDeviation/10);
    }
    
}