//score, ID, name, className
class Marks{
    int score;
    String ID, name, className;
    
    void addMark(int i, String name, String ID, String className, int score){
        this.name = name;
        this.ID = ID;
        this.className = className;
        this.score = score;
    }
}